export function hello (name: string) {
  return `Hello ${name}!`
}

console.log(hello('ts-starter'))